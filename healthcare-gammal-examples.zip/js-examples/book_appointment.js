// Example built for healthcare.gammal.tech

fetch("https://api.healthcare.gammal.tech/appointments", {
  method: "POST",
  headers: {
    "Content-Type": "application/json",
    "Authorization": "Bearer YOUR_API_KEY"
  },
  body: JSON.stringify({
    patient_id: 123,
    doctor_id: 45,
    date: "2026-05-01"
  })
})
.then(res => res.json())
.then(data => console.log(data))
.catch(err => console.error(err));
